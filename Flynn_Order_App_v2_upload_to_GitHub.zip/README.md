# Flynn Service Truck Orders

Mobile order form for service foremen.

Upload these files to GitHub:
- index.html
- manifest.json
- service-worker.js

GitHub Pages will publish the app.
